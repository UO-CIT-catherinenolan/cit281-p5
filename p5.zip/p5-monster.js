module.exports = class Monster {
    constructor ({
        monsterName = "Unknown", 
        minimumLife = 0, 
        currentLife = 100, 

    })
    {
        this.monsterName = monsterName; 
        this.minimumLife = minimumLife; 
        this.currentLife = currentLife; 
        this.isAlive = (currentLife >= minimumLife) ? true : false; 
        this.status = this.isAlive ? "Alive" : "Dead";
    }
    updateLife = (lifeChangeAmount = 0) => {
        let newLife = this.currentLife - lifeChangeAmount; 
        this.currentLife = (newLife <= 0) ? 0 : newLife; 
        this.isAlive = (this.currentLife >= this.minimumLife) ? true : false; 
        this.status = this.isAlive ? "Alive" : "Dead"; 
    }; 
    randomLifeDrain = (minimumLifeDrain, maximumLifeDrain) => {
        let r = (minimumLifeDrain < maximumLifeDrain)? 
        this.getRandomInteger (minimumLifeDrain, maximumLifeDrain + 1) : 0; 
        console.log (`${this.monsterName} rnadom power drain of ${r}`);
        this.updateLife (r); 
        }
    getRandomInteger = (min, max) => Math.floor(Math.random() * (max - min) + min); 
}

